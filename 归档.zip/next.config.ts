import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  /* 开启后导出静态 HTML 文件 */
  // output: "export"
};

export default nextConfig;
