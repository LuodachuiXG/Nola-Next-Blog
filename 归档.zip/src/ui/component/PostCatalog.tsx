'use client';

/**
 * 文章目录组件
 */
export function PostCatalog() {
  return <>目录</>;
}
