import { Metadata } from 'next';


export const metadata: Metadata = {
  title: '标签'
}

/**
 * 播客标签页面
 * @constructor
 */
export default function TagPage() {
  return (
    <div>
      Tag
    </div>
  )
}